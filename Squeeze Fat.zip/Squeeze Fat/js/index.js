$(document).ready(function(e) {
        
		$('#trigger').click(function(e) { 
			$('#main-menu').stop().slideToggle();
		});	
		
					
		$('nav a').click(function(e) { 
			$.scrollTo(this.hash || 0, 1500);
			e.preventDefault( ); 
		});
		
		$('.vegas').vegas({
			slides:[
                {src:'imgs/bg1.jpg'},
                {src:'imgs/bg2.jpg'},
				{src:'imgs/bg1.jpg',
					video:{
						src:['video/mainVideo.mp4','video/mainVideo.webm']				
					},
				},{src:'imgs/bg2.jpg'}
			],
            animation:'random',
            delay:12000
		});
		
		var container = $('#rt-wrap');
	
		container.isotope({
			animationEngine : 'best-available',
			animationOptions: {
				duration: 200,
				queue: false
			},
			layoutMode: 'fitRows'
		});	
	
		$('#filters a').click(function(){
			$('#filters a').removeClass('active');
			$(this).addClass('active');
			var selector = $(this).attr('data-filter');
			container.isotope({ filter: selector });
			setProjects();		
			return false;
		});		
		
		function splitColumns( ) { 
			var winWidth = $(window).width( ), columnNumb = 1;			
			
			if (winWidth > 1024) {
				columnNumb = 4;
			} else if (winWidth > 900) {
				columnNumb = 2;
			} else if (winWidth > 479) {
				columnNumb = 2;
			} else if (winWidth < 479) {
				columnNumb = 1;
			}
			
			return columnNumb;
		}		
		
		function setColumns( ) { 
			var winWidth = $(window).width( ), 
				columnNumb = splitColumns( ), 
				postWidth = Math.floor(winWidth / columnNumb);
			
			container.find('.rt-item').each(function () { 
				$(this).css( { 
					width : postWidth + 'px' 
				});
			});
		}		
		
		function setProjects( ) {
			setColumns( );
			container.isotope('reLayout');
		}
        
        
        $(".btn-submit").click(function(){
            var heigh = $("input.height").val();
            var hei = $("input.height").val()/100;
            var wei = $("input.weight").val();
            
            var result = wei/(hei*hei);
                        
            if(result < 18.5){
                var text = "저체중 입니다."
                $(".result-text").val(text);
                $(".bmi-result").val(result);
                $(".pi-height").val(heigh);
                $(".pi-weight").val(wei);
            }else if(result >= 18.5 && result < 23){
                var text = "정상체중 입니다."
                $(".result-text").val(text);
                $(".bmi-result").val(result);
                $(".pi-height").val(heigh);
                $(".pi-weight").val(wei);
            }else if(result >= 23 && result < 25){
                var text = "과체중 입니다."
                $(".result-text").val(text);
                $(".bmi-result").val(result);
                $(".pi-height").val(heigh);
                $(".pi-weight").val(wei);
            }else if(result >= 25){
                var text = "비만 입니다."
                $(".result-text").val(text);
                $(".bmi-result").val(result);
                $(".pi-height").val(heigh);
                $(".pi-weight").val(wei);
            }else {
                alert("키와 몸무게를 입력해주세요");
            }
        });
    
        $("input.btn-nw").click(function(){
            var hi = $(".pi-height").val()/100;
            var sex = $("input[name='customRadioInline1']:checked").val();
            var kgresult = 0;
            if(sex === "male" ){
                kgresult = hi * hi * 22;
                $("input.text-nw").val(kgresult);
            }else if(sex === "female"){
                kgresult = hi * hi * 21;
                $("input.text-nw").val(kgresult);
            }else {
                alert("다시 한번 확인 해주세요.");
            }                
        });
    
        $(".btn-obl").click(function(){
            var nw = $("input.text-nw").val();
            var weit = $(".pi-weight").val();
            var pibwresult = weit/nw *100;
            
            if( pibwresult<90){
                var textresult = "저체중 입니다.";
                $(".text-pibw").val(pibwresult);
                $(".text-dia").val(textresult);
            }else if(pibwresult>=90 && pibwresult<110){
                var textresult = "정상체중 입니다.";
                $(".text-pibw").val(pibwresult);
                $(".text-dia").val(textresult);                
            }else if(pibwresult>=110 && pibwresult<120){
                var textresult = "과체중 입니다.";
                $(".text-pibw").val(pibwresult);
                $(".text-dia").val(textresult);
            }else if(pibwresult>=120){
                var textresult = "비만 입니다.";
                $(".text-pibw").val(pibwresult);
                $(".text-dia").val(textresult);
            }else {
                alert("다시 한번 확인 해주세요.");
            }
        });
							
		
		
    });